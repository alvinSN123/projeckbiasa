package com.binakarir.binakarirapss.Model;

public class Model_Artikel_Psikolog {
    private String nama_artikel_Psikolog;
    private String gambar_artikel_Psikolog;
    private String link_artikel_Psikolog;

    public String getNama_artikel_Psikolog() {
        return nama_artikel_Psikolog;
    }

    public String getGambar_artikel_Psikolog() {
        return gambar_artikel_Psikolog;
    }

    public String getLink_artikel_Psikolog() {
        return link_artikel_Psikolog;
    }
}
