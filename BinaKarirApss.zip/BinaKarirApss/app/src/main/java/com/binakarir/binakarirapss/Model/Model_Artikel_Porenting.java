package com.binakarir.binakarirapss.Model;

public class Model_Artikel_Porenting {
    private String nama_artikel_Porenting;
    private String gambar_artikel_Porenting;
    private String link_artikel_Porenting;

    public String getNama_artikel_Porenting() {
        return nama_artikel_Porenting;
    }

    public String getGambar_artikel_Porenting() {
        return gambar_artikel_Porenting;
    }

    public String getLink_artikel_Porenting() {
        return link_artikel_Porenting;
    }
}
