package com.binakarir.binakarirapss.Model;

public class Model_Ebook {
    private String nama_ebook;
    private String cover_Ebook;

    public String getNama_ebook() {
        return nama_ebook;
    }

    public String getCover_Ebook() {
        return cover_Ebook;
    }
}
