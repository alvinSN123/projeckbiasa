package com.binakarir.binakarirapss.Model;

public class Model_Banner_Beranda {
     private String name;
     private String image;


    public String getName() {
        return name;
    }

    public String getImage() {
        return image;
    }

}
