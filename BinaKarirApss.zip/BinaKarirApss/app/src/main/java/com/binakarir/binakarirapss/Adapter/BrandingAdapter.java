package com.binakarir.binakarirapss.Adapter;

public class BrandingAdapter {
}
