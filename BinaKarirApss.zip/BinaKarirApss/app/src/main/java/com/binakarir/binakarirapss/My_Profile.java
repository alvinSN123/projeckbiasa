package com.binakarir.binakarirapss;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class My_Profile extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my__profile);
    }
}
