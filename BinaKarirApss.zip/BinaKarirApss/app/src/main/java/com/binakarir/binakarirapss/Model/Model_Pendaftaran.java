package com.binakarir.binakarirapss.Model;

public class Model_Pendaftaran {
    private String nama_lengkap_pendaftaran;
    private String email_pendaftaran;
    private String nohp_pendaftaran;
    private String id_instagram_pendaftaran;
    private String kota_domisili_pendaftaran;
    private String jumlah_pendaftaran;
    private String jurusan_kuliah_pendaftaran_s1;
    private String universitas_pendaftaran_s1;
    private String jurusan_kuliah_pendaftaran_s2;
    private String universitas_pendaftaran_s2;
    private String pekerjaan_pendaftaran;
    private String Perusahaan_pedaftaran;

    public void setNama_lengkap_pendaftaran(String nama_lengkap_pendaftaran) {
        this.nama_lengkap_pendaftaran = nama_lengkap_pendaftaran;
    }

    public void setEmail_pendaftaran(String email_pendaftaran) {
        this.email_pendaftaran = email_pendaftaran;
    }

    public void setNohp_pendaftaran(String nohp_pendaftaran) {
        this.nohp_pendaftaran = nohp_pendaftaran;
    }

    public void setId_instagram_pendaftaran(String id_instagram_pendaftaran) {
        this.id_instagram_pendaftaran = id_instagram_pendaftaran;
    }

    public void setKota_domisili_pendaftaran(String kota_domisili_pendaftaran) {
        this.kota_domisili_pendaftaran = kota_domisili_pendaftaran;
    }

    public void setJumlah_pendaftaran(String jumlah_pendaftaran) {
        this.jumlah_pendaftaran = jumlah_pendaftaran;
    }

    public void setJurusan_kuliah_pendaftaran_s1(String jurusan_kuliah_pendaftaran_s1) {
        this.jurusan_kuliah_pendaftaran_s1 = jurusan_kuliah_pendaftaran_s1;
    }

    public void setUniversitas_pendaftaran_s1(String universitas_pendaftaran_s1) {
        this.universitas_pendaftaran_s1 = universitas_pendaftaran_s1;
    }

    public void setJurusan_kuliah_pendaftaran_s2(String jurusan_kuliah_pendaftaran_s2) {
        this.jurusan_kuliah_pendaftaran_s2 = jurusan_kuliah_pendaftaran_s2;
    }

    public void setUniversitas_pendaftaran_s2(String universitas_pendaftaran_s2) {
        this.universitas_pendaftaran_s2 = universitas_pendaftaran_s2;
    }

    public void setPekerjaan_pendaftaran(String pekerjaan_pendaftaran) {
        this.pekerjaan_pendaftaran = pekerjaan_pendaftaran;
    }

    public void setPerusahaan_pedaftaran(String perusahaan_pedaftaran) {
        Perusahaan_pedaftaran = perusahaan_pedaftaran;
    }
}
