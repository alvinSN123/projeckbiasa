package com.binakarir.binakarirapss.Model;

public class Model_Artikel_HRD {
    private String nama_artikel_HRD;
    private String gambar_artikel_HRD;
    private String link_artikel_HRD;

    public String getNama_artikel_HRD() {
        return nama_artikel_HRD;
    }

    public String getGambar_artikel_HRD() {
        return gambar_artikel_HRD;
    }

    public String getLink_artikel_HRD() {
        return link_artikel_HRD;
    }
}
